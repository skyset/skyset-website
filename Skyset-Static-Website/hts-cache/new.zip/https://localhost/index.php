<!DOCTYPE html>
<html lang="en" dir="ltr">


<head>
    <!-- 

This is kind of the "head" for every page. It doesn't include the brackets
because i love myself. Any code in here should generate head-only HTML

-->

<meta charset="utf-8">

<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="description" content="Samuel Tyler is a Virginia-based designer specializing in digital media.">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- favicon -->

<link rel="apple-touch-icon" sizes="180x180" href="images/favicon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="images/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="images/favicon/favicon-16x16.png">
<link rel="manifest" href="images/favicon/site.webmanifest">

<!-- fonts -->

<link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Rowdies">
<link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Work Sans">
<!-- <link href="css/rowdies/latin.css" type="text/css" rel="stylesheet">
<link href="css/work-sans/latin.css" type="text/css" rel="stylesheet"> -->
<link href="css/material-icons/iconfont/material-icons.css" type="text/css" rel="stylesheet">

<!-- site css -->

<link href="css/header.css" type="text/css" rel="stylesheet">
<link href="css/hamburger.css" type="text/css" rel="stylesheet">
<link href="css/footer.css" type="text/css" rel="stylesheet">
<link href="css/socials.css" type="text/css" rel="stylesheet">
<link href="css/header.css" type="text/css" rel="stylesheet">
<link href="css/main.css" type="text/css" rel="stylesheet">

<!-- php -->


<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        $('.toggler').click(function(){
            $(this).toggleClass('toggled');
            $('.dropdownbg').toggleClass('shown');
        });
    });
</script>
<script src="https://www.google.com/recaptcha/api.js"></script>

<!--wait until css loaded to show page 
    from https://stackoverflow.com/questions/4172281/force-browsers-to-load-css-before-showing-the-page-->    <title>Skyset</title>
</head>

<body>
    <div id="wrapper">
        <!-- Hamburger Menu -->
<button class='toggler'>
  <span class='menu_icons'>
    <div id='hamburger_icon'><span class="material-icons">density_medium</span></div>
    <div id='hamburger_x'><span class="material-icons">clear</span></div>
  </span>
</button>

<!-- Header -->
<header>
  <div class="headerbg">
    <a href="index.php">  
      <img id="logo" src="images/logo.svg">
    </a>
  </div>
  <div class="dropdownbg">
    <nav>
      <ul>
        <li><a href="index">Home</a></li>
        <li><a href="about">About</a></li>
        <li><a href="contact">Contact</a></li>
        <li class="dropdown">
          <a href="portfolio">Portfolio<span class="material-icons">keyboard_arrow_down</span></a>
          <div>
            <a href="branding">Branding</a>
            <a href="illustration">Illustration</a>
          </div>
        </li>
      </ul>
    </nav>
  </div>
</header>        <main>
            <div id="index" class="hero">
                <div id="logo_capsule">
                    <video id="spinning_logo" poster="images/index/webp/skyset-still.webp" autoplay loop>
                        <source type="video/webm" src="images/index/skyset-animated.webm" />
                        <source type="video/mp4" src="images/index/skyset-animated.mp4" />
                    </video>

                    <picture id="logotype">
                        <source type="image/webp" src="images\index\skyset-logotype.webp" />
                        <img src="images\index\webp\skyset-logotype.webp" alt="Skyset logotype" />
                    </picture>

                    <span class="subtitle rowdies">MULTIMEDIA</span>
                </div>
                <p class="padded_15 flex_col flex_center w_40 margin_3">
                    Graphic design, frontend development, and illustration, all with one key principle:</br>
                <span class="padded_3 flex flex_center rowdies fit-width medium light_weight">
                    Simplicity is key. <span class="material-icons">auto_awesome</span>
                </span>
                </p>

            </div>
        </main>
        <footer class="border_top">
    <ul class='socials rowdies'><li><a href='https://dribbble.com/skyset'><picture><source srcset='./images/socials/webp/dribbble.webp' /><source srcset='./images/socials/dribbble.png' /><img src='./images/socials/webp/dribbble.webp' alt='dribbble' /></picture><span class='small caps'>dribbble</span></a></li><li><a href='https://www.behance.net/skyset'><picture><source srcset='./images/socials/webp/behance.webp' /><source srcset='./images/socials/behance.png' /><img src='./images/socials/webp/behance.webp' alt='behance' /></picture><span class='small caps'>behance</span></a></li><li><a href='https://www.linkedin.com/in/samuel-t-b72b55113/'><picture><source srcset='./images/socials/webp/linkedin.webp' /><source srcset='./images/socials/linkedin.png' /><img src='./images/socials/webp/linkedin.webp' alt='linkedin' /></picture><span class='small caps'>linkedin</span></a></li><li><a href='https://www.twitter.com/samskyset/'><picture><source srcset='./images/socials/webp/twitter.webp' /><source srcset='./images/socials/twitter.png' /><img src='./images/socials/webp/twitter.webp' alt='twitter' /></picture><span class='small caps'>twitter</span></a></li><li><a href='httpS://github.com/skyset'><picture><source srcset='./images/socials/webp/github.webp' /><source srcset='./images/socials/github.png' /><img src='./images/socials/webp/github.webp' alt='github' /></picture><span class='small caps'>github</span></a></li></ul>    <span>
        <p>Copyright &copy; 2023 Samuel Tyler</p>
        <p> <a href="mailto:samuel.e.tyler@gmail.com">samuel.e.tyler@gmail.com</a></p>
        <p>
            <span class="inline small">Site source on
                <a href="https://github.com/skyset/skyset-website">
                    GitHub
                    <span class="material-icons inline small">
                        settings_ethernet
                    </span>
                </a>
            </span>
        </p>
    </span>
</footer>    </div>
</body>

</html>